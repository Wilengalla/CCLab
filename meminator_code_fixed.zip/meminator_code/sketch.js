let memeBkg = [];
let memeImages = [];
let bkgButtons = [];
let activeBkgImage = false;
let buttonSpacing = 125;
let stickerButtons = [];
let stickers = [];
let freq;
let sinValue;
let sound = []

function preload(){
  for(let i = 0; i < 6; i++){
    memeBkg.push(loadImage("MemeBackground/Meme" + i + ".jpeg"));
  }
  for (let i = 0; i < 6; i++) {
    memeImages.push(loadImage("Memes/meme" + i + ".png")); // Change the file extension based on your image format
  }
  for(let i = 0; i < 1; i++){
    sound.push(loadSound("MemeSongs/memeSong" + i + ".mp3"));
  }
  
}

function setup() {
  let canvas = createCanvas(windowWidth, windowHeight);
  canvas.parent("canvasContainer");

 
  stickerButtons.push(new Sticker1(100, 500));

  let totalWidth = memeBkg.length * (70 + buttonSpacing);
  let startX = (width - totalWidth) / 2;

  for(let i = 0; i < memeBkg.length; i++){
    let buttonX = startX + i * (70 + buttonSpacing);
    bkgButtons.push(new BkgButton(buttonX, 110, memeBkg[i], 175, 125));
  }
  
}

function draw() {
  background("black");
  rect(325, 250, windowWidth/2, windowHeight/2);
  for(let i = 0; i < bkgButtons.length; i++) {
    bkgButtons[i].update();
    bkgButtons[i].display();
  }

  if (activeBkgImage !== false) {
    image(activeBkgImage, 325, 250, windowWidth/2, windowHeight/2);
    push();
    noFill();
    stroke(255);
    strokeWeight(2);
    rect(325, 250, windowWidth / 2, windowHeight / 2);
    pop();
  }

  for(let i = 0; i < stickerButtons.length; i++){
    stickerButtons[i].update();
    stickerButtons[i].display();
  }

  // Display all the stickers in use
  for(let i = 0; i < stickers.length; i++){
    stickers[i].update();
    stickers[i].display();
  }
}

function mouseClicked() {
  for(let i = 0; i < bkgButtons.length; i++) {
    if (bkgButtons[i].checkIfClicked()) {
      activeBkgImage = bkgButtons[i].image;
    }
  }
}

class BkgButton{
  constructor(startX, startY, memeBkg, width, height){
    this.x = startX;
    this.y = startY;
    this.image = memeBkg;
    this.width = width
    this.height = height;
    this.isSelected == false;
  }
  update(){

  }
  display(){
    push();
    translate(this.x, this.y);
    if (this.isSelected == true) {
      stroke("white");
      strokeWeight(5);
      noFill();
      rect(0, 0, this.width, this.height);
    }
    image(this.image, 0, 0, this.width, this.height);
    pop();
  }
  checkIfClicked() {
    if (mouseX >= this.x && mouseX <= this.x + this.width && mouseY >= this.y && mouseY <= this.y + this.height) {
        this.isSelected = true; // Corrected from this.isSelected == true
        return true;
    } else {
        this.isSelected = false; // Corrected from this.isSelected == false
        return false;
    }
  }
}

class Sticker1 {
  constructor(startX, startY, img) {
    this.x = startX;
    this.y = startY;
    this.imgY = 475
    this.startY = startY;
    this.width = 125; 
    this.height = 125;
    this.isBeingDragged = false;
    this.image = memeImages[1];
    this.frameCount = 0;
    this.freq = 0.01; // Adjust frequency to control speed of the oscillation
    this.amplitude = 25; // Adjust amplitude to control height of the oscillation
    this.sound = sound[0];
  }

  update() {
    // For the stickers in use, setting
    // this property to true allows us to drag it
    if (this.isBeingDragged) {
      this.x = mouseX - this.width / 2;
      this.y = mouseY - this.height / 2;
      this.imgY = mouseY - this.height/2
      this.sound.play();
    }

    // Update the position of the sun
    this.frameCount++;
    let sinValue = sin(this.frameCount * this.freq);
    this.y = this.startY + sinValue * this.amplitude; // Use this.startY instead of startY
  }

  display() {
    push();
    translate(this.x, this.imgY)
    fill("yellow");
    circle(63, this.y-480 ,105);
    image(this.image, 0, 0, this.width, this.height);
    pop();
    
  }

  isPressed() {
    // Check if the mouse is over the draggable area of the sticker
    return (
      mouseX > this.x &&
      mouseX < this.x + this.width &&
      mouseY > this.imgY &&
      mouseY < this.imgY + this.height
    );
  }
  isInsideRectangle() {
    let rectX = 325;
    let rectY = 250;
    let rectWidth = windowWidth / 2;
    let rectHeight = windowHeight / 2;

    return (
      this.x > rectX &&
      this.x + this.width < rectX + rectWidth &&
      this.imgY > rectY &&
      this.imgY + this.height < rectY + rectHeight
    );
  }
  
}





function mousePressed(){
  for(let i = stickers.length-1; i >= 0; i--){
    // If clicked, set isBeingDragged to true
    if(stickers[i].isPressed()){
      stickers[i].isBeingDragged = true;
      break; // Break the loop after one sticker is clicked
    }
  }
  
  // Loop over sticker buttons and check if clicked
  for(let i = stickerButtons.length-1; i >= 0; i--){
    if(stickerButtons[i].isPressed()){
      let newSticker = new Sticker1(mouseX, mouseY);
      newSticker.isBeingDragged = true;
      stickers.push(newSticker);
    }
  }
}

function mouseReleased(){
  // Set all stickers' isBeingDragged to false
  for(let i = 0; i < stickers.length; i++){
    stickers[i].isBeingDragged = false;
  }
  sound.stop();
}